package cat.udl.eps.ed.practica2.stack;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class ArrayStackTest {

    @Test
    void pop_on_empty_stack_should_throw_nse_exception() {
        var emptyStack = new ArrayStack<Integer>();
        assertThrows(NoSuchElementException.class, () -> {
            emptyStack.pop();
        });
    }

    @Test
    @DisplayName("pop() on empty stack should throw a NoSuchElement exception")
    void test1() {
        var emptyStack = new ArrayStack<Integer>();
        assertThrows(NoSuchElementException.class, () -> {
            emptyStack.pop();
        });
    }
    @Test
    @DisplayName("top() on empty stack should throw a NoSuchElement exception")
    void top_on_empty_stack_should_throw_nse_exception() {
        var emptyStack = new ArrayStack<Integer>();
        assertThrows(NoSuchElementException.class, () -> {
            emptyStack.top();
        });
    }

    @Test
    @DisplayName("should return the top element after pushing elements")
    void push_and_top() {
        var stack = new ArrayStack<Integer>();
        stack.push(1);
        stack.push(2);
        assertEquals(2, stack.top(), "Top should return the last pushed element");
    }

    @Test
    @DisplayName("should increase the size when elements are pushed")
    void push_increases_size() {
        var stack = new ArrayStack<Integer>();
        stack.push(1);
        stack.push(2);
        assertEquals(2, stack.size, "Size should increase with each push");
    }

    @Test
    @DisplayName("pop() should remove the top element")
    void pop_removes_top_element() {
        var stack = new ArrayStack<Integer>();
        stack.push(1);
        stack.push(2);
        stack.pop();
        assertEquals(1, stack.top(), "After pop, top should return the previous element");
    }

    @Test
    @DisplayName("pop() should decrease the size")
    void pop_decreases_size() {
        var stack = new ArrayStack<Integer>();
        stack.push(1);
        stack.push(2);
        stack.pop();
        assertEquals(1, stack.size, "Size should decrease after pop");
    }

    @Test
    @DisplayName("should return true for an empty stack")
    void is_empty_on_new_stack() {
        var stack = new ArrayStack<Integer>();
        assertTrue(stack.isEmpty(), "New stack should be empty");
    }

    @Test
    @DisplayName("should resize the array when pushing beyond capacity")
    void push_resizes_array() {
        var stack = new ArrayStack<Integer>();
        for (int i = 0; i < 15; i++) {
            stack.push(i); // Pushing more than the default capacity
        }
        assertEquals(15, stack.size, "Size should be equal to the number of pushed elements");
        assertEquals(14, stack.top(), "Top should return the last pushed element after resizing");
    }
}

