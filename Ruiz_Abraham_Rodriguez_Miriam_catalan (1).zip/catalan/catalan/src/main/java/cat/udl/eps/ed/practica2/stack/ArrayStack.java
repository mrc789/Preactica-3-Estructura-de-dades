package cat.udl.eps.ed.practica2.stack;

import java.util.NoSuchElementException;

/**
 * An implementation of a stack using an extensible array
 *
 * @param <E> the type of elements in the stack
 * @see Stack
 */
public class ArrayStack<E> implements Stack<E> {
    private E[] elements; // Array to hold stack elements
    public int size;     // Current size of the stack
    private static final int DEFAULT_CAPACITY = 10; // Default capacity
    /**
     * Creates an empty stack
     * @implNote
     * Uses a default size of 10 to create the array
     */
    public ArrayStack() {
        elements = (E[]) new Object[DEFAULT_CAPACITY]; // Initialize the array
        size = 0; // Initial size
    }

    /**
     * Adds an element to the top of the stack.
     *
     * @implNote
     *  If there is no room in the stack, the size of the array is doubled
     *
     * @param elem the element to be added
     */
    @Override
    public void push(E elem) {
        if (size == elements.length) {
            resize(2 * elements.length); // Double the size of the array if it's full
        }
        elements[size++] = elem; // Add element and increment size
    }

    /**
     * Returns the element at the top of the stack.
     *
     * @return the element at the top of the stack
     * @throws NoSuchElementException if the stack is empty
     */
    @Override
    public E top() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        return elements[size - 1]; // Return the top element
    }

    /**
     * Removes the element at the top of the stack.
     *
     * @throws NoSuchElementException if the stack is empty
     */
    @Override
    public void pop() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        elements[--size] = null; // Clear the reference and decrement size
    }

    /**
     * Returns true if the stack is empty, false otherwise.
     *
     * @return true if the stack is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return size == 0; // Return true if size is 0
    }

    // Method to resize the underlying array
    @SuppressWarnings("unchecked")
    private void resize(int capacity) {
        E[] newArray = (E[]) new Object[capacity]; // Create a new array with the new capacity
        System.arraycopy(elements, 0, newArray, 0, size); // Copy elements to the new array
        elements = newArray; // Replace the old array
    }
}
