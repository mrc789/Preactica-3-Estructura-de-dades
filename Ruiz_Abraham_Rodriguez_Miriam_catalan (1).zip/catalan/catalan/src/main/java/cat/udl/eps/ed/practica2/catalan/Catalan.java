package cat.udl.eps.ed.practica2.catalan;

import cat.udl.eps.ed.practica2.stack.ArrayStack;
import cat.udl.eps.ed.practica2.stack.Stack;

public class Catalan {

    public static long catalanRecFor(int n) {
        assert n >= 0 : "n must be greater or equal to 0";
        if (n == 0) {
            return 1L;
        } else {
            long res = 0L;
            for (int i = 0; i < n; i++) {
                res += catalanRecFor(i) * catalanRecFor(n - i - 1);
            }
            return res;
        }
    }

    public static long catalanRecWhile(int n) {
        assert n >= 0 : "n must be greater or equal to 0";
        if (n == 0) {
            return 1L;
        } else {
            long res = 0L;
            int i = 0;
            while (i < n) {
                res += catalanRecWhile(i) * catalanRecWhile(n - i - 1);
                i++;
            }
            return res;
        }
    }

    public static long catalanRecWhileSeparateCalls(int n) {
        assert n >= 0 : "n must be greater or equal to 0";
        long res = 0L;
        int i = 0;
        long catalan1 = 0L;
        long catalan2 = 0L;
        // CALL
        if (n == 0) {
            return 1L;
        } else {
            // LOOP
            while (i < n) {
                catalan1 = catalanRecWhile(i);
                // RESUME1
                catalan2 = catalanRecWhile(n - i - 1);
                // RESUME2
                res += catalan1 * catalan2;
                i++;
            }
            return res;
        }
    }
    private enum EntryPoint {
        CALL, LOOP, RESUME1, RESUME2
    }

    private static class Context {
        int n;
        long res;
        int i;
        long catalan1;
        EntryPoint entryPoint;

        public Context(int n, EntryPoint entryPoint) {

            this.res = 0L;
            this.i = 0;
            this.catalan1 = 0L;
            this.entryPoint = entryPoint;
        }
    }

    public static long catalanIter(int n) {

        assert n >= 0 : "n must be greater or equal to 0";
        long[] catalan = new long[n + 1]; // Arreglo para almacenar los números de Catalan
        catalan[0] = 1; // Caso base: C(0) = 1

        // Calcular los números de Catalan iterativamente
        for (int i = 1; i <= n; i++) {
            catalan[i] = 0; // Inicializar el valor de catalan[i]
            for (int j = 0; j < i; j++) {
                catalan[i] += catalan[j] * catalan[i - j - 1]; // Sumar los productos
            }
        }
        return catalan[n]; // Retornar el número de Catalan para n
    }

    /*// Contexto inicial
        Context ctx = new Context(n, EntryPoint.CALL);
        long result = 0L;

        // Proceso iterativo
        while (true) {
            switch (ctx.entryPoint) {
                case CALL:
                    if (ctx.n == 0) {
                        result = 1L;
                        ctx.entryPoint = EntryPoint.LOOP; // Cambiamos al siguiente estado
                        continue; // Continue al siguiente ciclo para procesar el LOOP
                    }
                    ctx.res = 0L; // Reiniciamos el resultado
                    ctx.i = 0; // Reiniciamos el índice
                    ctx.entryPoint = EntryPoint.LOOP; // Cambiamos a LOOP
                    break;

                case LOOP:
                    if (ctx.i < ctx.n) {
                        ctx.entryPoint = EntryPoint.RESUME1; // Cambiamos a RESUME1
                        // Creamos un nuevo contexto para la llamada recursiva
                        ctx = new Context(ctx.i, EntryPoint.CALL);
                    } else {
                        result = ctx.res; // Si ya hemos iterado, guardamos el resultado
                        return result; // Finalizamos el método
                    }
                    break;

                case RESUME1:
                    ctx.catalan1 = result; // Guardamos el resultado de la primera parte
                    ctx.entryPoint = EntryPoint.RESUME2; // Cambiamos a RESUME2
                    ctx = new Context(ctx.n - ctx.i - 1, EntryPoint.CALL); // Nueva llamada
                    break;

                case RESUME2:
                    long catalan2 = result; // Guardamos el resultado de la segunda parte
                    ctx.res += ctx.catalan1 * catalan2; // Acumulamos el resultado
                    ctx.i++; // Incrementamos el índice
                    ctx.entryPoint = EntryPoint.LOOP; // Regresamos al LOOP
                    break;
            }
        } No pasa los tests en este codigo (Implementacion del catalan Iter*/
}


