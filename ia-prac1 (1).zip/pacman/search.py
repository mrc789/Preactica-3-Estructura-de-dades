# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from game import Directions
from typing import List

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()




def tinyMazeSearch(problem: SearchProblem) -> List[Directions]:
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem: SearchProblem) -> List[Directions]:
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))


    Important note: All of your search functions need to return a list of actions that will lead the agent from the start to the goal. 
                    These actions all have to be legal moves (valid directions, no moving through walls).

    Important note: Make sure to use the Stack, Queue and PriorityQueue data structures provided to you in util.py! 
                    These data structure implementations have particular properties which are required for compatibility with the autograder.

    """
    "*** YOUR CODE HERE ***"
    "util.raiseNotDefined()"
    fringe = util.Stack()  # Cola para nodos a explorar
    start_state = problem.getStartState()
    fringe.push((start_state, []))  # Añadimos el estado inicial a la cola
    expanded = []  # Conjunto para nodos ya explorados

    if problem.isGoalState(start_state):
        return []

    while not fringe.isEmpty():
        current_state, actions = fringe.pop()
        if current_state not in expanded:
            expanded.append(current_state)
            if problem.isGoalState(current_state):
                return actions        

        for successor, action, cost in problem.getSuccessors(current_state):
            if successor not in expanded:
                new_actions = actions + [action]
                fringe.push((successor, new_actions))

    return []  



def breadthFirstSearch(problem: SearchProblem) -> List[Directions]:
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    fringe = util.Queue()  
    start_state = problem.getStartState()
    fringe.push((start_state, []))  
    expanded = []

    if problem.isGoalState(start_state):
        return []
    
    while not fringe.isEmpty():
        current_state, actions = fringe.pop()
        if current_state in expanded:
            continue
        if problem.isGoalState(current_state):
            return actions
        expanded.append(current_state)

        for successor, action, cost in problem.getSuccessors(current_state):
            if successor not in expanded:
                new_actions = actions + [action]
                fringe.push((successor, new_actions))

    return []


"""def uniformCostSearch(problem: SearchProblem) -> List[Directions]:
    Search the node of least total cost first.
    "*** YOUR CODE HERE ***"
    "util.raiseNotDefined()"
    fringe = util.PriorityQueue()  
    start_state = problem.getStartState()
    fringe.push((start_state, []), 0)  
    expanded = []

    while not fringe.isEmpty():
        current_state, actions = fringe.pop()
        if current_state not in expanded:
            expanded.append(current_state)
        else: continue

        if problem.isGoalState(current_state):
            return actions

        for successor, action, cost in problem.getSuccessors(current_state):
            new_actions = actions + [action]
            cost = problem.getCostOfActions(new_actions)
            successor_cost = problem.getCostOfActions(actions)
            if successor not in expanded or cost < successor_cost:
                fringe.push((successor, new_actions), cost)

    return []"""

def uniformCostSearch(problem: SearchProblem) -> List[Directions]:
    fringe = util.PriorityQueue()  
    start_state = problem.getStartState()
    fringe.push([start_state, [], 0], 0)  
    expanded = []

    while not fringe.isEmpty():
        node = fringe.pop()

        if problem.isGoalState(node[0]):
            return node[1]
        if node[0] not in expanded:
            expanded.append(node[0])

            for successor, action, cost in problem.getSuccessors(node[0]):
                new_actions = node[1] + [action]
                new_cost = node[2] + cost
                fringe.push((successor, new_actions, new_cost), new_cost)

    return []



def nullHeuristic(state, problem=None) -> float:
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

"""def aStarSearch(problem: SearchProblem, heuristic=nullHeuristic) -> List[Directions]:
    Search the node that has the lowest combined cost and heuristic first.
    "*** YOUR CODE HERE ***"
    "util.raiseNotDefined()"
    fringe = util.PriorityQueue()  
    start_state = problem.getStartState()
    fringe.push((start_state, []), 0)  
    expanded = []

    if problem.isGoalState(start_state):
        return []

    while not fringe.isEmpty():
        current_state, actions = fringe.pop()

        if current_state not in expanded:
            expanded.append(current_state)

            if problem.isGoalState(current_state):
                return actions

        for successor, action, cost in problem.getSuccessors(current_state):
            new_actions = actions + [action]
            cost = problem.getCostOfActions(new_actions) + heuristic(successor, problem)            
            if successor not in expanded:
                fringe.push((successor, new_actions), cost)
            
    return []"""

def aStarSearch(problem: SearchProblem, heuristic=nullHeuristic) -> List[Directions]:
    fringe = util.PriorityQueue()  
    start_state = problem.getStartState()
    fringe.push((start_state, [], 0), 0)  

    expanded = {problem.getStartState():0}

    while not fringe.isEmpty():
        node = fringe.pop()

        if problem.isGoalState(node[0]):
            return node[1]

        for successor, action, cost in problem.getSuccessors(node[0]):
            new_actions = node[1] + [action]
            prev_cost = node[2] + cost
            total_cost = prev_cost + heuristic(successor, problem)
            if successor not in expanded or prev_cost < expanded[successor]:
                expanded[successor] = prev_cost 
                fringe.push((successor, new_actions, prev_cost), total_cost)

    return []



# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
